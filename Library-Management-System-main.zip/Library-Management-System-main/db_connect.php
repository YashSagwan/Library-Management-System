<?php
	$con = mysqli_connect('localhost', 'root', '', 'librarygh');
	if(!$con)
		die("ERROR: Couldn't connect to database");
?>